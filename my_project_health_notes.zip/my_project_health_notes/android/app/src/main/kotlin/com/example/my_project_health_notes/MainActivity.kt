package com.example.my_project_health_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
